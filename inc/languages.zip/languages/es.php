<?php
$lang['metaLang'] = 'en';
$lang['title'] = 'SnapPDF';
$lang['desc'] = 'SnapPDF';
